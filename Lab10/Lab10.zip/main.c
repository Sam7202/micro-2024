#include "setting_hardaware/setting.h"
#include <stdlib.h>
#include "stdio.h"
#include "string.h"
// using namespace std;
#define _XTAL_FREQ 4000000
char str[20];
int num = 0;
int count_num = 0;
//
void Mode1(){   // Todo : Mode1 
    set_binary_bulb(num);
    return ;
}
//bonus
void Mode2(){   // Todo : Mode2 
    set_binary_bulb(count_num);
    return ;
}


void main(void) 
{
    
    SYSTEM_Initialize() ;

    
    while(1) {
        
//        test_bulb();
//        set_binary_bulb(num);
        strcpy(str, GetString()); // TODO : GetString() in uart.c
        if(str[0]=='m' && str[1]=='1'){ // Mode1
            Mode1();
            ClearBuffer();
        }
        else if(str[0]=='m' && str[1]=='2'){ // Mode2
            Mode2();
            ClearBuffer();  
        }
    }
    return;
}
char c ;
void __interrupt(high_priority) Hi_ISR(void)
{   
    if(PIR1bits.TXIF){   
        
    }
    if(PIR1bits.RCIF)
    {  
        if(RCSTAbits.OERR)
        {
            CREN = 0;
            Nop();
            CREN = 1;
        }
        c= MyusartRead();
        if(c =='\r'){
            UART_Write('\n');
        }
        UART_Write(c);
        //light up : advance
        if(c>='0' && c<='9'){
            num = c-'0';
            set_timer_continue();
            count_num = 0;  //reset to 0
        }

        return;
       
    }
     //bonus
      //isr of btn
    else if(INTCONbits.INT0F){
        //bouncing problem
        __delay_ms(50);
        T1CONbits.TMR1ON = 0;    // Stop Timer1
        INTCONbits.INT0F = 0;
        UART_Write_Text("btn pressed\n\r");
    }
    else if (PIR1bits.TMR1IF) {  // Check if Timer1 interrupt occurred
        UART_Write_Text("Timer1 Interrupt Triggered\n\r");
        //task
        reset_TMR1();      // Reload Timer1 low byte
        count_num++;
        //if < 0 reset to  original num
        if(count_num == num+1){
            count_num = 0;
        }
        PIR1bits.TMR1IF = 0;   // Clear interrupt flag

        return;
    }

    return;
    
}
// void interrupt low_priority Lo_ISR(void)
void __interrupt(low_priority)  Lo_ISR(void)
{   
   
//   // process other interrupt sources here, if required
    return;
}