/* 
 * File:   bulb.h
 * Author: user
 *
 * Created on 2024?12?18?, ?? 12:16
 */

#ifndef BULB_H
#define	BULB_H
#include <xc.h> 
void initial_bulb();
void set_binary_bulb(int num);
void test_bulb();


#endif

