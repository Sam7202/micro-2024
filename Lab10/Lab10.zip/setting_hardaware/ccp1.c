#include <xc.h>

void CCP1_Initialize() {
    //need to modify----------------------------------------------------
    // Timer2 -> On, prescaler -> 4
    T2CONbits.TMR2ON = 0b1;
    T2CONbits.T2CKPS = 0b01;
    
    // Internal Oscillator Frequency, Fosc = 125 kHz, Tosc = 8 �s
//    OSCCONbits.IRCF = 0b001;
    //--------------------------------------------------------
    // PWM mode, P1A, P1C active-high; P1B, P1D active-high
    CCP1CONbits.CCP1M = 0b1100;
    
    // CCP1/RC2 -> Output
    TRISC = 0;
    LATC = 0;
    
    // Set up PR2, CCP to decide PWM period and Duty Cycle
    /** 
     * PWM period
     * = (PR2 + 1) * 4 * Tosc * (TMR2 prescaler)
     * = (0x9b + 1) * 4 * 8�s * 4
     * = 0.019968s ~= 20ms
     */
    PR2 = 0x9b;
    
    /**
     * 500 ~ 2400 �s (-90 ~ 90, 1450 us = 0)
     * Duty cycle
     * = (CCPR1L:CCP1CON<5:4>) * Tosc * (TMR2 prescaler)
     * = (0x0b*4 + 0b01) * 8�s * 4
     * = 0.00144s ~= 1450�s
     * 
     */
    //initial motor to -90 deg
    CCPR1L = 4;
    CCP1CONbits.DC1B = 0;
//    CCP1CON=9;		// Compare mode, initialize CCP1 pin high, clear output on compare match
    //interupt of CCP(no need)

}
