#include "setting_hardaware/setting.h"
#include <stdlib.h>
#include "stdio.h"
#include "string.h"
#include <math.h>
// using namespace std;
#define _XTAL_FREQ 500000
#define THRESH 1          //thteshold on ADC vlaue to update LATB
char str[20];
int num = 0;
int count_num = 0;
int flash_count = 0;
int state = 0;
int seq[8] = {1,4,1,0,6,0,5,8};
int x = 100;
//
void Mode1(){   // Todo : Mode1 
    set_binary_bulb(num);
    return ;
}
//bonus
void Mode2(){   // Todo : Mode2 
    set_binary_bulb(count_num);
    return ;
}

void adc_action(){
    //step4   
        int value = ADC_Read();  
        int deg = value/1024.0 *90.0;
        static int pre_value = 0;

        //prevent chage too fast, only chage LATB on value change > Threshold
        if(abs(value - pre_value )>THRESH){
            //3-b: map 0 - 1024 to 10 to 600
            x = 10.0 + (601.0-10.0) * (value/1024.0);
            sprintf(str,"%d\n\r",x );
            
            UART_Write_Text(str);
            //3-a: set deg of motor (0 to 90)
            int r_8b,r_2b;
            set_deg(deg,&r_8b,&r_2b);
            CCPR1L = r_8b & 0b11111111;
            CCP1CONbits.DC1B = r_2b & 0b00000011;
            //update pre value
            pre_value = value;
        }
        
        
        //step5 & go back step3
        /*
        delay at least 2tad
        */
//        __delay_ms(1000);
        ADCON0bits.GO = 1;
//        UART_Write_Text("ADC triggered from main\n\r");
}
void main(void) 
{
    
    SYSTEM_Initialize() ;
  
    while(1) {
        adc_action();
        
        
        
//        adc_action();
//        test_bulb();
//        set_binary_bulb(num);
//        strcpy(str, GetString()); // TODO : GetString() in uart.c
//        if(str[0]=='m' && str[1]=='1'){ // Mode1
//            Mode1();
//            ClearBuffer();
//        }
//        else if(str[0]=='m' && str[1]=='2'){ // Mode2
//            ClearBuffer();  
//        }
    }
    return;
}
char c ;
void __interrupt(high_priority) Hi_ISR(void)
{   
    //UART TXIREG no use
    if(PIR1bits.TXIF){   
        
    }
    //
    if(PIR1bits.RCIF)
    {  
        if(RCSTAbits.OERR)
        {
            CREN = 0;
            Nop();
            CREN = 1;
        }
        c= MyusartRead();
        if(c =='\r'){
            UART_Write('\n');
        }
        UART_Write(c);
        //light up : advance
        if(c>='0' && c<='9'){
            num = c-'0';
//            set_timer_continue();
            count_num = 0;  //reset to 0
        }
       return;
       
    }
   
    //isr of btn
    if(INTCONbits.INT0F){
        //bouncing problem
        __delay_ms(50);
        T1CONbits.TMR1ON = 0;    // Stop Timer1
        INTCONbits.INT0F = 0;
        UART_Write_Text("btn pressed\n\r");
    }
    
    //TMR1
    else if (PIR1bits.TMR1IF) {  // Check if Timer1 interrupt occurred
        sprintf(str,"State_%d count %d\n\r",state,flash_count );
        //task
        reset_TMR1();      // Reload Timer1 low byte
        PIR1bits.TMR1IF = 0;   // Clear interrupt flag
        
        
//        UART_Write_Text("Timer1 Triggered\n\r");
//        LATD ^= 1;
        if(LATD == 0){
            LATD = 1;
            flash_count++;
            UART_Write_Text(str);
        }
        else{
            LATD = 0;
            
        }
        

    }
    //ADC isr
    else if(PIR1bits.ADIF){
        //clear flag bit
        PIR1bits.ADIF = 0;
        adc_action();
//        UART_Write_Text("ADC triggered\n\r");
    }
    

    return;
    
}
// void interrupt low_priority Lo_ISR(void)
void __interrupt(low_priority)  Lo_ISR(void)
{   
   
//   // process other interrupt sources here, if required
    return;
}