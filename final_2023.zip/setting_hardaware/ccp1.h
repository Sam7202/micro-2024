#ifndef _CCP1_H
#define	_CCP1_H

#include <xc.h> // include processor files - each processor file is guarded.  

void set_deg(int deg,int *r_8b,int *r_2b);
void CCP1_Initialize();
#endif	

