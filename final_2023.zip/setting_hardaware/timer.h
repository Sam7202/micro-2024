

#ifndef TINER_H
#define	TINER_H
#include <xc.h>
void TMR2_Initialize();
void TMR1_Initialize();
void TMR0_Initialize();
void set_TMR1_s(float time);
void reset_TMR1();
void set_timer_continue();


#endif	/* TIMER_H */

